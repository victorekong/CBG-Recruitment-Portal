﻿using GCBrecruitment.Models;
using Logger;
using System;
using System.Collections.Generic;
using Newtonsoft.Json;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Mail;
using System.Web;
using System.Web.Http;
using System.Text;

namespace GCBrecruitment.Controllers
{

    public class RecruitController : ApiController
    {
        static System.Reflection.Assembly appname = System.Reflection.Assembly.GetExecutingAssembly();

        [Route("api/ValidateEmail")]
        [HttpPost]
        public IHttpActionResult ValidateEmail(Utility.EmailRequest Email, HttpRequestMessage request)
        {
            string mthname = System.Reflection.MethodBase.GetCurrentMethod().Name;
            Logger.GeneralLog filter = new Logger.GeneralLog(appname.FullName.Split(',')[0], mthname, ApplicationType.WebApplication);
            filter.LogRequest(new string[] { Email.Email });
            try
            {
                if (!ConfirmDomain(Email.Email))
                {
                    throw new Exception("Invalid Email Submitted");
                }
                if (Helper.EmailExist(Email.Email)) throw new Exception("Application previously received.");

                //return Json(new { code = "00", message = "Successful" });
            }
            catch (Exception E)
            {
                filter.LogError(E);
                Helper.LogExceptionDB(E);
                filter.LogResponse(new string[] { (Content(HttpStatusCode.BadRequest, E.Message)).Content });
                return Content(HttpStatusCode.BadRequest, E.Message);
            }
            filter.LogResponse(new string[] { Json(new { code = "00", message = "Successful" }).Content.ToString() });
            return Json(new { code = "00", message = "Successful" });
        }

        [Route("api/AddApplication")]
        [HttpPost]
        public IHttpActionResult NewApplication()
        {
            string mthname = System.Reflection.MethodBase.GetCurrentMethod().Name;
            Logger.GeneralLog filter = new Logger.GeneralLog(appname.FullName.Split(',')[0], mthname, ApplicationType.WebApplication);
            string FileName = string.Empty;
            string JsonObj = string.Empty;
            string NewFileName = string.Empty;
            string ext = string.Empty;

            HttpRequest Request = HttpContext.Current.Request;



            //string json = JSON.Encode(new { HttpContext.Current.Request.Form, HttpContext.Current.Request.Params });
            try
            {

                if (Request.TotalBytes > 0)
                {
                    JsonObj = Encoding.Default.GetString(Request.BinaryRead(Request.TotalBytes));
                    //filter.LogRequest(new string[] { JsonObj });
                    //Get Uploaded file

                    // Get the uploaded file from the Files collection
                    var httpPostedFile = HttpContext.Current.Request.Files["CV"];
                    //var name = HttpContext.Current.Request.Form["Name"];
                    if (httpPostedFile != null)
                    {
                        // Validate the uploaded image(optional)


                        var FileSize = httpPostedFile.ContentLength;
                        var FileSizeMB = (FileSize / 1024f) / 1024f;
                        FileName = httpPostedFile.FileName;
                        if (!(FileName.ToUpper().Contains("PDF") || FileName.ToUpper().Contains("DOC") || FileName.ToUpper().Contains("DOCX"))) return Content(HttpStatusCode.BadRequest, "Invalid File type uploaded");
                        if (FileSizeMB > 2) return Content(HttpStatusCode.BadRequest, "File is too large");
                        ext = FileName.Split('.')[1];

                    }
                    else { throw new Exception("No File Uploaded"); }


                    // Get the posted form
                    var httpPostedForm = HttpContext.Current.Request.Form;

                    if (httpPostedForm != null)
                    {
                        if (Helper.EmailExist(HttpContext.Current.Request.Form["Email"])) throw new Exception("Duplicate Application");
                        NewFileName = string.Format("{0}_{1}_{2}.{3}", HttpContext.Current.Request.Form["FirstName"], HttpContext.Current.Request.Form["MiddleName"], HttpContext.Current.Request.Form["Surname"], ext);
                        var Application = new Utility.ApplicationRequest
                        {
                            Email = HttpContext.Current.Request.Form["Email"],
                            FirstName = HttpContext.Current.Request.Form["FirstName"],
                            MiddleName = HttpContext.Current.Request.Form["MiddleName"],
                            Surname = HttpContext.Current.Request.Form["Surname"],
                            CumulativeYearsOfExperience = HttpContext.Current.Request.Form["CumulativeYearsOfExperience"],
                            CurrentGrade = HttpContext.Current.Request.Form["CurrentGrade"],
                            Gender = HttpContext.Current.Request.Form["Gender"],
                            DateOfBirth = HttpContext.Current.Request.Form["DateOfBirth"],
                            DateOfLastPromotion = HttpContext.Current.Request.Form["DateOfLastPromotion"],
                            Function = HttpContext.Current.Request.Form["Function"],
                            Grade = HttpContext.Current.Request.Form["Grade"],
                            HighestEduQualification = HttpContext.Current.Request.Form["HighestEduQualification"],
                            JobTitle = HttpContext.Current.Request.Form["JobTitle"],
                            MemberBank = HttpContext.Current.Request.Form["MemberBank"],
                            ProfessionalCert = HttpContext.Current.Request.Form["ProfessionalCert"],
                            Title = HttpContext.Current.Request.Form["Title"],
                            YearsOfEmployment = HttpContext.Current.Request.Form["YearsOfEmployment"],
                            CV = FileName
                        };

                        filter.LogRequest(new string[] { string.Format("No of fields found: {0}", HttpContext.Current.Request.Form.Count.ToString()) });
                        Helper.CreateApplication(Application);


                    }
                    else { throw new Exception("No form details"); }

                    //Create folder
                    var CVLocation = Path.Combine(@"c:", "/UploadedCVs");
                    if (!Directory.Exists(CVLocation)) Directory.CreateDirectory(CVLocation);
                    // Get the complete file path
                    var fileSavePath = Path.Combine(CVLocation, NewFileName);
                    httpPostedFile.SaveAs(fileSavePath);
                    //Helper.SendMail();
                }
                else
                {
                    throw new Exception("No Content Message");
                }


            }
            catch (Exception E)
            {
                filter.LogError(E);
                Helper.LogExceptionDB(E);
                filter.LogResponse(new string[] { (Content(HttpStatusCode.BadRequest, E.Message)).Content });
                return Content(HttpStatusCode.BadRequest, E.Message);
            }
            filter.LogResponse(new string[] { Json(new { code = "00", message = "Thank you, we have received your application and it is currently being processed." }).Content.ToString() });
            return Json(new { code = "00", message = "Thank you, we have received your application and it is currently being processed." });
        }

        [Route("api/GetAllApplications")]
        [HttpGet]
        public IHttpActionResult GetAllApplications()
        {
            string mthname = System.Reflection.MethodBase.GetCurrentMethod().Name;
            Logger.GeneralLog filter = new Logger.GeneralLog(appname.FullName.Split(',')[0], mthname, ApplicationType.WebApplication);
            string json =string.Empty;
            try
            {
                var Applications = Helper.GetAll();

                if (Applications.Count() < 1) throw new Exception("No job application found!");

                json = JsonConvert.SerializeObject(Applications);
            }
            catch(Exception E)
            {
                filter.LogError(E);
                Helper.LogExceptionDB(E);
                filter.LogResponse(new string[] { (Content(HttpStatusCode.BadRequest, E.Message)).Content });
                return Content(HttpStatusCode.BadRequest, E.Message);
            }
            return Ok(json);
        }


        private bool ConfirmDomain(string Email)
        {
            bool resp = false;
            try
            {
                // Create a list of domains.
                List<Utility.Domain> EmailDomains = new List<Utility.Domain>();
                EmailDomains.Add(new Utility.Domain() { DomainName = "thebeigebank.com" });
                EmailDomains.Add(new Utility.Domain() { DomainName = "theroyalbank.com.gh" });
                EmailDomains.Add(new Utility.Domain() { DomainName = "unibankghana.com" });
                EmailDomains.Add(new Utility.Domain() { DomainName = "theconstructionbank.com" });
                EmailDomains.Add(new Utility.Domain() { DomainName = "sovereignbankghana.com" });

                MailAddress address = new MailAddress(Email);
                string host = address.Host;
                resp = EmailDomains.Select(c => c.DomainName).Contains(host);
            }
            catch (Exception Ex)
            {
                throw (Ex);
            }
            return resp;
        }



        //public IHttpActionResult NewApplication(Utility.ApplicationRequest Application, HttpRequestMessage request)
        //{
        //    try
        //    {
        //        filter.LogRequest(new string[] { Application.Email });

        //        if (Helper.EmailExist(Application.Email)) throw new Exception("Duplicate Application");

        //        if (HttpContext.Current.Request.Files.AllKeys.Any())
        //        {
        //            // Get the uploaded image from the Files collection
        //            var httpPostedFile = HttpContext.Current.Request.Files["UploadedImage"];

        //            if (httpPostedFile != null)
        //            {
        //                // Validate the uploaded image(optional)

        //                // Get the complete file path
        //                var fileSavePath = Path.Combine(HttpContext.Current.Server.MapPath("~/UploadedFiles"), httpPostedFile.FileName);
        //                var u = httpPostedFile.ContentType;
        //                // Save the uploaded file to "UploadedFiles" folder
        //                httpPostedFile.SaveAs(fileSavePath);

        //            }
        //        }

        //        Helper.CreateApplication(Application);
        //    }
        //    catch (Exception E)
        //    {
        //        filter.LogError(E);
        //        throw (E);
        //    }


        //    return Json(new { code = "00", message = "Successful" });
        //}
    }
}
