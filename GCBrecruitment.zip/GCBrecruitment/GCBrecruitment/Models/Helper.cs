﻿using Logger;
using SendGrid;
using SendGrid.Helpers.Mail;
using System;
using System.Collections.Generic;
using System.Data.Entity.Validation;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace GCBrecruitment.Models
{
    public class Helper
    {
        static System.Reflection.Assembly appname = System.Reflection.Assembly.GetExecutingAssembly();

        public static void CreateApplication(Utility.ApplicationRequest Application)
        {
            string mthname = System.Reflection.MethodBase.GetCurrentMethod().Name;
            Logger.GeneralLog filter = new Logger.GeneralLog(appname.FullName.Split(',')[0], mthname, ApplicationType.WebApplication);
            try
            {
                using (var DB = new CBGhanaRecruitmentPortalEntities())
                {

                    var AppID = DB.StaffAuthInfoes.Add(new StaffAuthInfo { EmailAddress = Application.Email });


                    var StaffBio = DB.StaffBioDatas.Add(new StaffBioData
                    {
                        CumulativeYearOfExperience = Convert.ToInt16(Application.CumulativeYearsOfExperience),
                        CurrentGrade = Application.CurrentGrade,
                        CVFileName = Application.CV,
                        DateCreated = DateTime.Now,
                        DateOfBirth = Convert.ToDateTime(Application.DateOfBirth),
                        EmploymentYearsInMemberBank = Convert.ToInt16(Application.YearsOfEmployment),
                        FirstName = Application.FirstName,
                        Surname = Application.Surname,
                        MiddleName = Application.MiddleName,
                        JobFunction = Application.Function,
                        JobTitle = Application.JobTitle,
                        Gender = Application.Gender,
                        HighestEduQualification = Application.HighestEduQualification,
                        LastPromotionDate = Convert.ToDateTime(Application.DateOfLastPromotion),
                        ProfessionalCertification = Application.ProfessionalCert,
                        StaffAuthInfoId = AppID.Id,
                        MemberBankId = Convert.ToInt16(Application.MemberBank),
                        Title = Application.Title
                    });

                    DB.SaveChanges();

                    //Application.CV.SaveAs(AppDomain.CurrentDomain.BaseDirectory + @"\" + Application.Email);

                    //var decode = new InfoPathAttachmentDecoder(Application.CV);
                    //File.WriteAllBytes(AppDomain.CurrentDomain.BaseDirectory + @"\" + Application.Email, bytes);


                }
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    filter.LogError(eve.ValidationErrors.ToString());
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                        filter.LogError(ve.ErrorMessage);
                    }
                }
                throw;
            }
            catch (Exception Ex)
            {
                //throw (Ex);
                filter.LogError(Ex);
                throw (Ex);
            }

        }

        public static bool EmailExist(string Email)
        {
            string mthname = System.Reflection.MethodBase.GetCurrentMethod().Name;
            Logger.GeneralLog filter = new Logger.GeneralLog(appname.FullName.Split(',')[0], mthname, ApplicationType.WebApplication);
            var ret = false;
            try
            {
                using (var DB = new CBGhanaRecruitmentPortalEntities())
                {
                    var details = DB.StaffAuthInfoes.Where(c => c.EmailAddress == Email).ToList();
                    if (details.Count > 0) ret = true;

                }
            }
            catch (Exception Ex)
            {
                throw (Ex);
            }
            return ret;
        }

        public static void LogExceptionDB(Exception Ex)
        {
            string mthname = System.Reflection.MethodBase.GetCurrentMethod().Name;
            Logger.GeneralLog filter = new Logger.GeneralLog(appname.FullName.Split(',')[0], mthname, ApplicationType.WebApplication);
            try
            {
                using (var DB = new CBGhanaRecruitmentPortalEntities())
                {
                    DB.ErrorLogs.Add(new ErrorLog
                    {
                        ErrorDate = DateTime.Now,
                        ErrorMessage = Ex.Message,
                        ErrorStackTrace = Ex.StackTrace,
                        ExceptionSource = Ex.Source,
                        ExceptionTargetSite = Ex.TargetSite.Name,
                        ExceptionTypeName = Ex.GetType().FullName
                    });
                    DB.SaveChanges();
                }
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    filter.LogError(eve.ValidationErrors.ToString());
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                        filter.LogError(ve.ErrorMessage);
                    }
                }
                throw;
            }
            catch (Exception E)
            {
                filter.LogError(E);
            }
        }

        public static List<Utility.StaffData> GetAll()
        {
            string mthname = System.Reflection.MethodBase.GetCurrentMethod().Name;
            Logger.GeneralLog filter = new Logger.GeneralLog(appname.FullName.Split(',')[0], mthname, ApplicationType.WebApplication);
            var Result = new List<Utility.StaffData>();
            try
            {
                using (var DB = new CBGhanaRecruitmentPortalEntities())
                {

                    Result = (from a in DB.StaffBioDatas
                                  where !string.IsNullOrEmpty(a.Surname)
                                  select new Utility.StaffData
                                  {
                                      FullName = (a.Title + " " + " " + a.FirstName + " " + a.MiddleName + " " + a.Surname),
                                      DateUploaded = a.DateCreated,
                                      Email = a.StaffAuthInfo.EmailAddress,
                                      Grade = a.CurrentGrade,
                                      JobTitle = a.JobTitle
                                  }).ToList();

                }
            }
            catch (Exception E)
            {
                filter.LogError(E);
                throw (E);
            }
            return Result;
        }

        public static void SendMail()
        {
            string mthname = System.Reflection.MethodBase.GetCurrentMethod().Name;
            Logger.GeneralLog filter = new Logger.GeneralLog(appname.FullName.Split(',')[0], mthname, ApplicationType.WebApplication);
            try
            {

                var htmlContent = "<!doctype html> <html>   <head>     <meta name=\"viewport\" content=\"width=device-width\">     <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">     <title>Simple Transactional Email</title>     <style>     /* -------------------------------------         INLINED WITH htmlemail.io/inline     ------------------------------------- */     /* -------------------------------------         RESPONSIVE AND MOBILE FRIENDLY STYLES     ------------------------------------- */     @media only screen and (max-width: 620px) {       table[class=body] h1 {         font-size: 28px !important;         margin-bottom: 10px !important;       }       table[class=body] p,             table[class=body] ul,             table[class=body] ol,             table[class=body] td,             table[class=body] span,             table[class=body] a {         font-size: 16px !important;       }       table[class=body] .wrapper,             table[class=body] .article {         padding: 10px !important;       }       table[class=body] .content {         padding: 0 !important;       }       table[class=body] .container {         padding: 0 !important;         width: 100% !important;       }       table[class=body] .main {         border-left-width: 0 !important;         border-radius: 0 !important;         border-right-width: 0 !important;       }       table[class=body] .btn table {         width: 100% !important;       }       table[class=body] .btn a {         width: 100% !important;       }       table[class=body] .img-responsive {         height: auto !important;         max-width: 100% !important;         width: auto !important;       }     }     /* -------------------------------------         PRESERVE THESE STYLES IN THE HEAD     ------------------------------------- */     @media all {       .ExternalClass {         width: 100%;       }       .ExternalClass,             .ExternalClass p,             .ExternalClass span,             .ExternalClass font,             .ExternalClass td,             .ExternalClass div {         line-height: 100%;       }       .apple-link a {         color: inherit !important;         font-family: inherit !important;         font-size: inherit !important;         font-weight: inherit !important;         line-height: inherit !important;         text-decoration: none !important;       }       .btn-primary table td:hover {         background-color: #34495e !important;       }       .btn-primary a:hover {         background-color: #34495e !important;         border-color: #34495e !important;       }     }     </style>   </head>   <body class=\"\" style=\"background-color: #f6f6f6; font-family: sans-serif; -webkit-font-smoothing: antialiased; font-size: 14px; line-height: 1.4; margin: 0; padding: 0; -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%;\">     <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" class=\"body\" style=\"border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; background-color: #f6f6f6;\">       <tr>         <td style=\"font-family: sans-serif; font-size: 14px; vertical-align: top;\">&nbsp;</td>         <td class=\"container\" style=\"font-family: sans-serif; font-size: 14px; vertical-align: top; display: block; Margin: 0 auto; max-width: 580px; padding: 10px; width: 580px;\">           <div class=\"content\" style=\"box-sizing: border-box; display: block; Margin: 0 auto; max-width: 580px; padding: 10px;\">              <!-- START CENTERED WHITE CONTAINER -->             <span class=\"preheader\" style=\"color: transparent; display: none; height: 0; max-height: 0; max-width: 0; opacity: 0; overflow: hidden; mso-hide: all; visibility: hidden; width: 0;\">This is preheader text. Some clients will show this text as a preview.</span>             <table class=\"main\" style=\"border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; background: #ffffff; border-radius: 3px;\">                <!-- START MAIN CONTENT AREA -->               <tr>                 <td class=\"wrapper\" style=\"font-family: sans-serif; font-size: 14px; vertical-align: top; box-sizing: border-box; padding: 20px;\">                   <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%;\">                     <tr>                       <td style=\"font-family: sans-serif; font-size: 14px; vertical-align: top;\">                         <p style=\"font-family: sans-serif; font-size: 14px; font-weight: normal; margin: 0; Margin-bottom: 15px;\">Hi <b>#FullName </b>,</p>                         <p style=\"font-family: sans-serif; font-size: 14px; font-weight: normal; margin: 0; Margin-bottom: 15px;\"> We acknowledge receipt of your resume and application for a position at <b> Consolidated Bank of Ghana  </b> and sincerely apreciate your interest in our company.   </p>                         <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" class=\"btn btn-primary\" style=\"border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: 100%; box-sizing: border-box;\">                           <tbody>                             <tr>                               <td align=\"left\" style=\"font-family: sans-serif; font-size: 14px; vertical-align: top; padding-bottom: 15px;\">                                 <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"border-collapse: separate; mso-table-lspace: 0pt; mso-table-rspace: 0pt; width: auto;\">                                   <tbody>                                     <tr>                                     </tr>                                   </tbody>                                 </table>                               </td>                             </tr>                           </tbody>                         </table>                         <p style=\"font-family: sans-serif; font-size: 14px; font-weight: normal; margin: 0; Margin-bottom: 15px;\">All applicants will be screened and candidates whose qualifications seem to meet our need.  We will carefully consider your application during the initial screening and will contact you if you are selected to continue in the recruitment process. </p>                         <p style=\"font-family: sans-serif; font-size: 14px; font-weight: normal; margin: 0; Margin-bottom: 15px;\">We wish you every success. Good luck! </p>                       </td>                     </tr>                   </table>                 </td>               </tr>             <!-- END MAIN CONTENT AREA -->             </table><!-- END CENTERED WHITE CONTAINER -->           </div>         </td>         <td style=\"font-family: sans-serif; font-size: 14px; vertical-align: top;\">&nbsp;</td>       </tr>     </table>   </body> </html>";

                Execute("SendGrid Test 2", "victor.j.ekong@ng.ey.com", "Victor Ekong", htmlContent).Wait();
            }
            catch(Exception E)
            {
                throw (E);
            }

        }

        static async Task Execute(string subject, string recipientEmailAddress, string recipientName, string htmlContent)
        {
            var apiKey = "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";
            var client = new SendGridClient(apiKey);
            var from = new EmailAddress("HR_Recruit@cbg.com", "CBG HR");
            var to = new EmailAddress(recipientEmailAddress, recipientName);
            //var plainTextContent = "and easy to do anywhere, even with C#";

            var msg = MailHelper.CreateSingleEmail(from, to, subject, "", htmlContent.Replace("#FullName", recipientName));
            var response = await client.SendEmailAsync(msg);
        }



    }
}