﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logger
{
    public class Log
    {
        public string ActivityDate { get; set; }
        public string MethodCalled { get; set; }
        public string RequestParams { get; set; }
        public string ResponseParams { get; set; }
        public string ClientIP { get; set; }
        public string Type { get; set; }
        public string ExceptionMessage { get; set; }
    }
}
