﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Text;
using System.Threading.Tasks;

namespace Logger
{
    public class GeneralLog
    {
        private string ApplicationName { get; set; }
        private string MethodName { get; set; }
        private string szAddress { get; set; }
        private string logLocation { get; set; }

        /// <summary>
        /// Use this constructor if you intend to keep a single instance of the WSProfiler
        /// for the given client aplication. To check if a client is permitted to call, 
        /// Use method CheckAccess(string clientIP, string methodName)
        /// </summary>
        /// <param name="ApplicationName"></param>
        public GeneralLog(string ApplicationName)
        {
            this.ApplicationName = ApplicationName;
            this.logLocation = ConfigurationManager.AppSettings["LogLocation"].ToString();
            //ProfileList = GetProfileList();
        }


        /// <summary>
        /// For WCF SOAP Web Service
        /// </summary>
        /// <param name="ApplicationName">Name of the application. Use  var ApplicationName = System.Reflection.Assembly.GetExecutingAssembly();</param>
        /// <param name="MethodName">Name of the method. Use  var MethodName = System.Reflection.MethodBase.GetCurrentMethod().Name.FullName.Split(',')[0]</param>
        public GeneralLog(string ApplicationName, string MethodName)
        {
            this.ApplicationName = ApplicationName;
            this.MethodName = MethodName;
            OperationContext oOperationContext = OperationContext.Current;
            MessageProperties oMessageProperties = oOperationContext.IncomingMessageProperties;
            RemoteEndpointMessageProperty oRemoteEndpointMessageProperty = (RemoteEndpointMessageProperty)oMessageProperties[RemoteEndpointMessageProperty.Name];
            string szAddress = oRemoteEndpointMessageProperty.Address;
            this.szAddress = szAddress;
            this.logLocation = ConfigurationManager.AppSettings["LogLocation"].ToString();
        }
        public GeneralLog(string ApplicationName, string MethodName, ApplicationType appType)
        {
            this.ApplicationName = ApplicationName;
            this.MethodName = MethodName;
            this.logLocation = ConfigurationManager.AppSettings["LogLocation"].ToString();
        }
        /// <summary>
        /// For WCF RESTFul Service or ASP.Net Web API
        /// </summary>
        /// <param name="ApplicationName">Name of the application. Use  var ApplicationName = System.Reflection.Assembly.GetExecutingAssembly();</param>
        /// <param name="MethodName">Name of the method. Use  var MethodName = System.Reflection.MethodBase.GetCurrentMethod().Name.FullName.Split(',')[0]</param>
        /// <param name="request"></param>
        public GeneralLog(string ApplicationName, string MethodName, HttpRequestMessage request)
        {
            this.ApplicationName = ApplicationName;
            this.MethodName = MethodName;
            string szAddress = request.GetClientIpAddress();
            this.szAddress = szAddress;
            this.logLocation = ConfigurationManager.AppSettings["LogLocation"].ToString();
        }
        public GeneralLog(string ApplicationName, HttpRequestMessage request)
        {
            this.ApplicationName = ApplicationName;
            this.MethodName = request.Method.Method.Trim() + "," + request.RequestUri.AbsoluteUri.Trim();
            this.logLocation = ConfigurationManager.AppSettings["LogLocation"].ToString();
            string szAddress = request.GetClientIpAddress();
            this.szAddress = szAddress;
        }
        public string GetApplicationName()
        {
            var appname = System.Reflection.Assembly.GetExecutingAssembly();
            this.logLocation = ConfigurationManager.AppSettings["LogLocation"].ToString();
            return appname.FullName.Split(',')[0];

        }
        public string GetCurrentMethodName()
        {
            var mthname = System.Reflection.MethodBase.GetCurrentMethod().Name;
            return mthname;
        }

        //private IList<ClientAccessDTO> GetProfileList()
        //{
        //    var appName = ApplicationName.Trim();
        //    var result = new List<ClientAccessDTO>();
        //    using (var context = new DapperMicroORM.DapperContext())
        //    {
        //        result = context.Connection.Query<ClientAccessDTO>(SqlQueryTemplateAll, new { ApplicationName = appName }).ToList();
        //    }
        //    return result;
        //}

        /// <summary>
        /// Use this method only if you have instantiated WSProfiler as a single instance
        /// (static) on the client side with the constructor
        /// WSProfile(string ApplicationName)
        /// </summary>
        /// <param name="clientIP"></param>
        /// <param name="methodName"></param>
        /// <returns></returns>
        //public Filter CheckAccess(string clientIP, string methodName)
        //{
        //    var filter = (from v in ProfileList
        //                  where v.ClientIP == clientIP && v.MethodName == methodName
        //                  select new Filter { HasAccess = true, DoPost = v.DoPost }).FirstOrDefault();
        //    if (filter == null)
        //    {
        //        Log("Unauthorized access attempt on Method: " + methodName);
        //        return new Filter { HasAccess = false, DoPost = false };
        //    }
        //    return filter;
        //}

        //public Filter FilterMth()
        //{
        //    //OperationContext oOperationContext = OperationContext.Current;
        //    //MessageProperties oMessageProperties = oOperationContext.IncomingMessageProperties;
        //    //RemoteEndpointMessageProperty oRemoteEndpointMessageProperty = (RemoteEndpointMessageProperty)oMessageProperties[RemoteEndpointMessageProperty.Name];
        //    //string szAddress = oRemoteEndpointMessageProperty.Address;
        //    var mthName = MethodName.Trim();
        //    var appName = ApplicationName.Trim();
        //    using (var db = new WSProfilerEntities())
        //    {
        //        var ipmtds = db.ClientProfiles.FirstOrDefault(s => s.ClientIP == szAddress);
        //        if (ipmtds != null)
        //        {
        //            var ms = ipmtds.ClientMethods.Where(s => s.Application.AppName == appName);
        //            //var m = db.Methods.FirstOrDefault(s => s.MethodName == mthName);

        //            if (ms.Count() > 0)
        //            {
        //                var mth = ms.FirstOrDefault(s => s.Method.MethodName == mthName);
        //                //var mth = db.ClientMethods.FirstOrDefault(s => s.ClientId == ipmtds.Id && s.MethodId == m.Id);

        //                if (mth != null)
        //                {
        //                    return new Filter { HasAccess = true, DoPost = mth.DoPost};

        //                }
        //                else
        //                {
        //                    Log("Unauthorized access attempt on Method: "+mthName);
        //                    return new Filter { HasAccess = false, DoPost = false };
        //                }

        //            }
        //            else
        //            {
        //                Log("Unauthorized access attempt on Method: " + mthName);
        //                 return new Filter { HasAccess = false, DoPost = false };
        //            }
        //        }
        //        else
        //        {
        //            Log("Unauthorized access attempt on Method: " + mthName);
        //            return new Filter { HasAccess = false, DoPost = false };
        //        }
        //    }
        //}

        //public Filter FilterMth()
        //{

        //    var mthName = MethodName.Trim();
        //    var appName = ApplicationName.Trim();
        //    var result = new ClientAccessDTO();
        //    using (var context = new DapperMicroORM.DapperContext())
        //    {
        //        result = context.Connection.Query<ClientAccessDTO>(SqlQueryTemplate, new { ApplicationName = appName, MethodName = mthName, ClientIP = szAddress }).FirstOrDefault();
        //    }

        //    if (result == null)
        //    {
        //        Log("Unauthorized access attempt on Method: " + mthName);
        //        return new Filter { HasAccess = false, DoPost = false };
        //    }
        //    else
        //    {
        //        return new Filter { HasAccess = true, DoPost = result.DoPost };
        //    }
        //}

        private void ConfirmFilePath(string DropFolder)
        {
            try
            {
                if (!System.IO.Directory.Exists(DropFolder))
                {
                    System.IO.Directory.CreateDirectory(DropFolder);
                }
            }
            catch (Exception ex)
            {
                throw ex;

            }
        }
        public string LogRequest(string[] logitems)
        {
            return Log("Request", logitems);
        }
        public string LogResponse(string[] logitems)
        {
            return Log("Response", logitems);
        }
        public string Log(string LogType, string[] logitems)
        {
            // string msg = string.Empty;
            StringBuilder message = new StringBuilder();

            try
            {
                string _LogFile = ApplicationName + "Log.txt";
                string filePath = DateTime.Now.ToString("dd-MM-yyyy") + _LogFile;

                int gmtOffset = DateTime.Compare(DateTime.Now, DateTime.UtcNow);


                string errorDateTime = DateTime.Now.ToString("dd MMM yyyy HH:mm:ss");

                try
                {
                    var msg = string.Format("{0}.....{1}-Details-{2}", LogType, MethodName, string.Join(":", logitems.Select(s => "{" + s + "}").ToArray()));
                    //logitems.Select(s => "{" + s + "}");
                    string.Join(":", logitems.Select(s => "{" + s + "}").ToArray());
                    if (Directory.Exists(logLocation))
                    {
                        if (Directory.Exists(logLocation + ApplicationName + "/"))
                        {
                            string path = (logLocation + ApplicationName + "/" + filePath);

                            using (System.IO.StreamWriter sw = new StreamWriter(path, true))
                            {
                                sw.WriteLine("---------------------REQUEST FROM " + szAddress + "----------------------------------------");
                                sw.WriteLine("## " + errorDateTime + " ## ");
                                message.AppendLine(msg);
                                sw.WriteLine(message.ToString());
                                sw.WriteLine("---------------------REQUEST FROM " + szAddress + "------------------------------------------");
                                sw.Flush();
                                sw.Close();
                            }
                        }
                        else
                        {
                            Directory.CreateDirectory(logLocation + ApplicationName + "/");
                            string path = (logLocation + ApplicationName + "/" + filePath);

                            using (System.IO.StreamWriter sw = new StreamWriter(path, true))
                            {
                                sw.WriteLine("---------------------REQUEST FROM " + szAddress + "----------------------------------------");
                                sw.WriteLine("## " + errorDateTime + " ## ");
                                message.AppendLine(msg);
                                sw.WriteLine(message.ToString());
                                sw.WriteLine("---------------------REQUEST FROM " + szAddress + "------------------------------------------");
                                sw.Flush();
                                sw.Close();
                            }
                        }

                    }
                    else
                    {
                        //Directory.CreateDirectory(System.Web.HttpContext.Current.Server.MapPath("~/Logs/"));
                        //string path = System.Web.HttpContext.Current.Server.MapPath(Path.Combine("~/Logs/", filePath));



                        Directory.CreateDirectory(logLocation);
                        Directory.CreateDirectory(logLocation + ApplicationName + "/");
                        string path = (logLocation + ApplicationName + filePath);
                        using (System.IO.StreamWriter sw = new StreamWriter(path, true))
                        {
                            sw.WriteLine("----------------------------REQUEST FROM " + szAddress + "-----------------------------------");
                            sw.WriteLine("## " + errorDateTime + " ## ");
                            message.AppendLine(msg);
                            sw.WriteLine(message.ToString());
                            sw.WriteLine("----------------------------REQUEST FROM " + szAddress + "-----------------------------------");
                            sw.Flush();
                            sw.Close();
                        }
                    }
                }
                catch (Exception e)
                {
                    message.AppendLine(e.Message);
                    // msg = "";
                }

            }
            catch (Exception e2)
            {
                message.AppendLine(e2.Message);
                // msg = "";
            }

            return message.ToString();
        }
        public string LogError(string[] logitems)
        {
            // string msg = string.Empty;
            StringBuilder message = new StringBuilder();

            try
            {
                string _LogFile = ApplicationName + "ErrorLog.txt";
                string filePath = DateTime.Now.ToString("dd-MM-yyyy") + _LogFile;

                int gmtOffset = DateTime.Compare(DateTime.Now, DateTime.UtcNow);

                string errorDateTime = DateTime.Now.ToString("dd MMM yyyy HH:mm:ss");

                try
                {
                    var msg = string.Format("Error.....{0}-Details-{1}", MethodName, string.Join("\n", logitems.Select(s => "{" + s + "}").ToArray()));
                    //logitems.Select(s => "{" + s + "}");
                    //string.Join(":", logitems.Select(s => "{" + s + "}").ToArray());
                    if (Directory.Exists(logLocation))
                    {
                        if (Directory.Exists(logLocation + ApplicationName + "/"))
                        {
                            string path = (logLocation + ApplicationName + "/" + filePath);

                            using (System.IO.StreamWriter sw = new StreamWriter(path, true))
                            {
                                sw.WriteLine("---------------------REQUEST FROM " + szAddress + "----------------------------------------");
                                sw.WriteLine("## " + errorDateTime + " ## ");
                                message.AppendLine(msg);
                                sw.WriteLine(message.ToString());
                                sw.WriteLine("---------------------REQUEST FROM " + szAddress + "------------------------------------------");
                                sw.Flush();
                                sw.Close();
                            }
                        }
                        else
                        {
                            Directory.CreateDirectory(logLocation + ApplicationName + "/");
                            string path = (logLocation + ApplicationName + "/" + filePath);

                            using (System.IO.StreamWriter sw = new StreamWriter(path, true))
                            {
                                sw.WriteLine("---------------------REQUEST FROM " + szAddress + "----------------------------------------");
                                sw.WriteLine("## " + errorDateTime + " ## ");
                                message.AppendLine(msg);
                                sw.WriteLine(message.ToString());
                                sw.WriteLine("---------------------REQUEST FROM " + szAddress + "------------------------------------------");
                                sw.Flush();
                                sw.Close();
                            }
                        }

                    }
                    else
                    {
                        //Directory.CreateDirectory(System.Web.HttpContext.Current.Server.MapPath("~/Logs/"));
                        //string path = System.Web.HttpContext.Current.Server.MapPath(Path.Combine("~/Logs/", filePath));



                        Directory.CreateDirectory(logLocation);
                        Directory.CreateDirectory(logLocation + ApplicationName + "/");
                        string path = (logLocation + ApplicationName + filePath);
                        using (System.IO.StreamWriter sw = new StreamWriter(path, true))
                        {
                            sw.WriteLine("----------------------------REQUEST FROM " + szAddress + "-----------------------------------");
                            sw.WriteLine("## " + errorDateTime + " ## ");
                            message.AppendLine(msg);
                            sw.WriteLine(message.ToString());
                            sw.WriteLine("----------------------------REQUEST FROM " + szAddress + "-----------------------------------");
                            sw.Flush();
                            sw.Close();
                        }
                    }
                }
                catch (Exception e)
                {
                    message.AppendLine(e.Message);
                    // msg = "";
                }

            }
            catch (Exception e2)
            {
                message.AppendLine(e2.Message);
                // msg = "";
            }

            return message.ToString();
        }

        public string LogError(Exception exception)
        {
            // string msg = string.Empty;
            StringBuilder message = new StringBuilder();


            try
            {
                string _LogFile = ApplicationName + "ErrorLog.txt";
                string filePath = DateTime.Now.ToString("dd-MM-yyyy") + _LogFile;


                var items = new List<string>();

                items.Add(exception.Message);
                items.Add(exception.StackTrace);

                var logitems = items.ToArray();

                int gmtOffset = DateTime.Compare(DateTime.Now, DateTime.UtcNow);

                string errorDateTime = DateTime.Now.ToString("dd MMM yyyy HH:mm:ss");

                try
                {
                    var msg = string.Format("Error.....{0}-Details-{1}", MethodName, string.Join("\n", logitems.Select(s => "{" + s + "}").ToArray()));
                    //logitems.Select(s => "{" + s + "}");
                    //string.Join(":", logitems.Select(s => "{" + s + "}").ToArray());
                    if (Directory.Exists(logLocation))
                    {
                        if (Directory.Exists(logLocation + ApplicationName + "/"))
                        {
                            string path = (logLocation + ApplicationName + "/" + filePath);

                            using (System.IO.StreamWriter sw = new StreamWriter(path, true))
                            {
                                sw.WriteLine("---------------------REQUEST FROM " + szAddress + "----------------------------------------");
                                sw.WriteLine("## " + errorDateTime + " ## ");
                                message.AppendLine(msg);
                                sw.WriteLine(message.ToString());
                                sw.WriteLine("---------------------REQUEST FROM " + szAddress + "------------------------------------------");
                                sw.Flush();
                                sw.Close();
                            }
                        }
                        else
                        {
                            Directory.CreateDirectory(logLocation + ApplicationName + "/");
                            string path = (logLocation + ApplicationName + "/" + filePath);

                            using (System.IO.StreamWriter sw = new StreamWriter(path, true))
                            {
                                sw.WriteLine("---------------------REQUEST FROM " + szAddress + "----------------------------------------");
                                sw.WriteLine("## " + errorDateTime + " ## ");
                                message.AppendLine(msg);
                                sw.WriteLine(message.ToString());
                                sw.WriteLine("---------------------REQUEST FROM " + szAddress + "------------------------------------------");
                                sw.Flush();
                                sw.Close();
                            }
                        }

                    }
                    else
                    {
                        //Directory.CreateDirectory(System.Web.HttpContext.Current.Server.MapPath("~/Logs/"));
                        //string path = System.Web.HttpContext.Current.Server.MapPath(Path.Combine("~/Logs/", filePath));



                        Directory.CreateDirectory(logLocation);
                        Directory.CreateDirectory(logLocation + ApplicationName + "/");
                        string path = (logLocation + ApplicationName + filePath);
                        using (System.IO.StreamWriter sw = new StreamWriter(path, true))
                        {
                            sw.WriteLine("----------------------------REQUEST FROM " + szAddress + "-----------------------------------");
                            sw.WriteLine("## " + errorDateTime + " ## ");
                            message.AppendLine(msg);
                            sw.WriteLine(message.ToString());
                            sw.WriteLine("----------------------------REQUEST FROM " + szAddress + "-----------------------------------");
                            sw.Flush();
                            sw.Close();
                        }
                    }
                }
                catch (Exception e)
                {
                    message.AppendLine(e.Message);
                    // msg = "";
                }

            }
            catch (Exception e2)
            {
                message.AppendLine(e2.Message);
                // msg = "";
            }

            return message.ToString();
        }
        public string Log(string msg)
        {

            // string msg = string.Empty;
            StringBuilder message = new StringBuilder();
            try
            {
                string _LogFile = ApplicationName + "Log.txt";
                string filePath = DateTime.Now.ToString("dd-MM-yyyy") + _LogFile;

                int gmtOffset = DateTime.Compare(DateTime.Now, DateTime.UtcNow);


                string errorDateTime = DateTime.Now.ToString("dd MMM yyyy HH:mm:ss");

                try
                {
                    if (Directory.Exists(logLocation))
                    {
                        if (Directory.Exists(logLocation + ApplicationName + "/"))
                        {
                            string path = (logLocation + ApplicationName + "/" + filePath);

                            using (System.IO.StreamWriter sw = new StreamWriter(path, true))
                            {
                                sw.WriteLine("---------------------REQUEST FROM " + szAddress + "----------------------------------------");
                                sw.WriteLine("## " + errorDateTime + " ## ");
                                message.AppendLine(msg);
                                sw.WriteLine(message.ToString());
                                sw.WriteLine("---------------------REQUEST FROM " + szAddress + "------------------------------------------");
                                sw.Flush();
                                sw.Close();
                            }
                        }
                        else
                        {
                            Directory.CreateDirectory(logLocation + ApplicationName + "/");
                            string path = (logLocation + ApplicationName + "/" + filePath);

                            using (System.IO.StreamWriter sw = new StreamWriter(path, true))
                            {
                                sw.WriteLine("---------------------REQUEST FROM " + szAddress + "----------------------------------------");
                                sw.WriteLine("## " + errorDateTime + " ## ");
                                message.AppendLine(msg);
                                sw.WriteLine(message.ToString());
                                sw.WriteLine("---------------------REQUEST FROM " + szAddress + "------------------------------------------");
                                sw.Flush();
                                sw.Close();
                            }
                        }
                    }
                    else
                    {
                        //Directory.CreateDirectory(System.Web.HttpContext.Current.Server.MapPath("~/Logs/"));
                        //string path = System.Web.HttpContext.Current.Server.MapPath(Path.Combine("~/Logs/", filePath));



                        Directory.CreateDirectory(logLocation);
                        Directory.CreateDirectory(logLocation + ApplicationName + "/");
                        string path = (logLocation + ApplicationName + filePath);
                        using (System.IO.StreamWriter sw = new StreamWriter(path, true))
                        {
                            sw.WriteLine("----------------------------REQUEST FROM " + szAddress + "-----------------------------------");
                            sw.WriteLine("## " + errorDateTime + " ## ");
                            message.AppendLine(msg);
                            sw.WriteLine(message.ToString());
                            sw.WriteLine("----------------------------REQUEST FROM " + szAddress + "-----------------------------------");
                            sw.Flush();
                            sw.Close();
                        }
                    }
                }
                catch (Exception e)
                {
                    message.AppendLine(e.Message);
                    msg = "";
                }

            }
            catch (Exception e2)
            {
                message.AppendLine(e2.Message);
                msg = "";
            }

            return message.ToString();
        }
        public string LogError(string msg)
        {
            // string msg = string.Empty;
            StringBuilder message = new StringBuilder();
            try
            {
                string _LogFile = ApplicationName + "ErrorLog.txt";
                string filePath = DateTime.Now.ToString("dd-MM-yyyy") + _LogFile;

                int gmtOffset = DateTime.Compare(DateTime.Now, DateTime.UtcNow);

                string errorDateTime = DateTime.Now.ToString("dd MMM yyyy HH:mm:ss");

                try
                {
                    if (Directory.Exists(logLocation))
                    {
                        if (Directory.Exists(logLocation + ApplicationName + "/"))
                        {
                            string path = (logLocation + ApplicationName + "/" + filePath);

                            using (System.IO.StreamWriter sw = new StreamWriter(path, true))
                            {
                                sw.WriteLine("---------------------REQUEST FROM " + szAddress + "----------------------------------------");
                                sw.WriteLine("## " + errorDateTime + " ## ");
                                message.AppendLine(msg);
                                sw.WriteLine(message.ToString());
                                sw.WriteLine("---------------------REQUEST FROM " + szAddress + "------------------------------------------");
                                sw.Flush();
                                sw.Close();
                            }
                        }
                        else
                        {
                            Directory.CreateDirectory(logLocation + ApplicationName + "/");
                            string path = (logLocation + ApplicationName + "/" + filePath);

                            using (System.IO.StreamWriter sw = new StreamWriter(path, true))
                            {
                                sw.WriteLine("---------------------REQUEST FROM " + szAddress + "----------------------------------------");
                                sw.WriteLine("## " + errorDateTime + " ## ");
                                message.AppendLine(msg);
                                sw.WriteLine(message.ToString());
                                sw.WriteLine("---------------------REQUEST FROM " + szAddress + "------------------------------------------");
                                sw.Flush();
                                sw.Close();
                            }
                        }
                    }
                    else
                    {
                        //Directory.CreateDirectory(System.Web.HttpContext.Current.Server.MapPath("~/Logs/"));
                        //string path = System.Web.HttpContext.Current.Server.MapPath(Path.Combine("~/Logs/", filePath));



                        Directory.CreateDirectory(logLocation);
                        Directory.CreateDirectory(logLocation + ApplicationName + "/");
                        string path = (logLocation + ApplicationName + filePath);
                        using (System.IO.StreamWriter sw = new StreamWriter(path, true))
                        {
                            sw.WriteLine("----------------------------REQUEST FROM " + szAddress + "-----------------------------------");
                            sw.WriteLine("## " + errorDateTime + " ## ");
                            message.AppendLine(msg);
                            sw.WriteLine(message.ToString());
                            sw.WriteLine("----------------------------REQUEST FROM " + szAddress + "-----------------------------------");
                            sw.Flush();
                            sw.Close();
                        }
                    }
                }
                catch (Exception e)
                {
                    message.AppendLine(e.Message);
                    msg = "";
                }

            }
            catch (Exception e2)
            {
                message.AppendLine(e2.Message);
                msg = "";
            }

            return message.ToString();
        }
    }
    public enum ApplicationType
    {
        WebApplication,
        OtherApplication
    }
}
