﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace GCBrecruitment.Models
{
    public class Utility
    {
        public class EmailRequest
        {
            [Required(ErrorMessage = "Email is a required field.")]
            public string Email { get; set; }
        }
        public class Response
        {
            public string RespCode { get; set; }
            public string RespMsg { get; set; }
        }

        public class Domain : List<Domain>
        {
            public string DomainName { get; set; }
        }

        public class ApplicationRequest
        {
            [Required(ErrorMessage = "Email is a required field.")]
            public string Email { get; set; }
            [Required(ErrorMessage = "Surname is a required field.")]
            public string Surname { get; set; }
            [Required(ErrorMessage = "First Name is a required field.")]
            public string FirstName { get; set; }
            [Required(ErrorMessage = "Middle Name is a required field.")]
            public string MiddleName { get; set; }
            [Required(ErrorMessage = "Title is a required field.")]
            public string Title { get; set; }
            [Required(ErrorMessage = "MemberBank is a required field.")]
            public string MemberBank { get; set; }
            [Required(ErrorMessage = "CurrentGrade is a required field.")]
            public string CurrentGrade { get; set; }
            [Required(ErrorMessage = "JobTitle is a required field.")]
            public string JobTitle { get; set; }
            [Required(ErrorMessage = "Grade is a required field.")]
            public string Grade { get; set; }
            [Required(ErrorMessage = "Function is a required field.")]
            public string Function { get; set; }
            [Required(ErrorMessage = "Cumulative Years Of Experience is a required field.")]
            public string CumulativeYearsOfExperience { get; set; }
            [Required(ErrorMessage = "Years Of Employment is a required field.")]
            public string YearsOfEmployment { get; set; }
            [Required(ErrorMessage = "Date Of Last Promotion is a required field.")]
            public string DateOfLastPromotion { get; set; }
            public string ProfessionalCert { get; set; }
            [Required(ErrorMessage = "Gender is a required field.")]
            public string Gender { get; set; }
            [Required(ErrorMessage = "DoB is a required field.")]
            public string DateOfBirth { get; set; }
            [Required(ErrorMessage = "No CV Uploaded.")]
            public string CV { get; set; }
            [Required(ErrorMessage = "Highest Education Qualification is required.")]
            public string HighestEduQualification { get; set; }


        }

        public partial class StaffData
        {
            public string FullName { get; set; }
            public DateTime DateUploaded { get; set; }
            public string JobTitle { get; set; }
            public string Grade { get; set; }
            public string Email { get; set; }

        }
    }
}