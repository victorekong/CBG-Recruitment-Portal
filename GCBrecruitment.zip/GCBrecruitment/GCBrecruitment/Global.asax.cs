﻿using Logger;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;

namespace GCBrecruitment
{
    public class WebApiApplication : System.Web.HttpApplication
    {
        static System.Reflection.Assembly appname = System.Reflection.Assembly.GetExecutingAssembly();
        static string mthname = System.Reflection.MethodBase.GetCurrentMethod().Name;
        static Logger.GeneralLog filter = new Logger.GeneralLog(appname.FullName.Split(',')[0], mthname, ApplicationType.WebApplication);
        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();
            GlobalConfiguration.Configure(WebApiConfig.Register);
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);
        }
        //protected void Application_Error()
        //{
        //    var ex = Server.GetLastError();

        //    filter.LogError(ex);
        //}
    }
}
