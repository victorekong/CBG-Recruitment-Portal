﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Text;
using System.Threading.Tasks;

namespace Logger
{
    public class LogHelper
    {
        public class MyWebClient : WebClient
        {
            protected override WebRequest GetWebRequest(Uri uri)
            {
                WebRequest w = base.GetWebRequest(uri);
                w.Timeout = 10000;
                return w;
            }
        }

        public static class CommonHelper
        {
            public static T PostToWebApi<T>(object obj, Uri webApiUrl)
            {
                // Create a WebClient to POST the request
                MyWebClient client = new MyWebClient();
                {
                    // Set the header so it knows we are sending JSON
                    client.Headers[HttpRequestHeader.ContentType] = "application/json";

                    // Serialise the data we are sending in to JSON
                    string serialisedData = JsonConvert.SerializeObject(obj);

                    // Make the request
                    var response = client.UploadString(webApiUrl, serialisedData);

                    // Deserialise the response into a GUID
                    var result = JsonConvert.DeserializeObject<T>(response);
                    return result;

                    //client.Headers[HttpRequestHeader.ContentType] = "application/x-protobuf";
                    //byte[] data;
                    //using (var ms = new MemoryStream())
                    //{
                    //    ProtoBuf.Serializer.NonGeneric.Serialize(ms, obj);
                    //    data = ms.ToArray();
                    //}

                    //var response = client.UploadData(webApiUrl, data);

                    //using (var ms = new MemoryStream(response))
                    //{
                    //    var result = ProtoBuf.Serializer.Deserialize<T>(ms);

                    //    return result;
                    //}
                }
            }

            public static string GetClientIP(OperationContext opContext)
            {

                MessageProperties prop = opContext.IncomingMessageProperties;
                RemoteEndpointMessageProperty endpoint =
                prop[RemoteEndpointMessageProperty.Name] as RemoteEndpointMessageProperty;
                string ip = endpoint.Address;
                return ip;
            }

            public static void Log(Log log)
            {
                var line = Environment.NewLine;

                try
                {
                    string filepath = ConfigurationManager.AppSettings["USSDEnrolmentLog"];

                    if (!Directory.Exists(filepath))
                    {
                        Directory.CreateDirectory(filepath);
                    }
                    filepath = filepath + DateTime.Today.ToString("dd-MM-yy") + ".txt";   //Text File Name
                    if (!File.Exists(filepath))
                    {
                        File.Create(filepath).Dispose();
                    }
                    using (StreamWriter sw = File.AppendText(filepath))
                    {
                        StringBuilder builder = new StringBuilder();
                        builder.Append("--------------------------------------------------------------Log Details on " + " " + DateTime.Now.ToString() + "----------------------------------------------------");
                        builder.Append(line);
                        builder.AppendFormat("Date: {0}", log.ActivityDate);
                        builder.Append(line);
                        builder.AppendFormat("Method Called: {0}", log.MethodCalled);
                        builder.Append(line);
                        builder.AppendFormat("Request Params : {0}", log.RequestParams);
                        builder.Append(line);
                        builder.AppendFormat("Response Params: {0}", log.ResponseParams);
                        builder.Append(line);
                        builder.AppendFormat("Client IP: {0}", log.ClientIP);
                        builder.Append(line);
                        builder.AppendFormat("Type: {0}", log.Type);
                        builder.Append(line);
                        builder.AppendFormat("Message: {0}", log.ExceptionMessage);
                        builder.Append(line);
                        builder.Append("--------------------------------------------------------------Log Details on " + " " + DateTime.Now.ToString() + "----------------------------------------------------");
                        sw.WriteLine(builder.ToString());
                        sw.Flush();
                        sw.Close();

                    }

                }
                catch (Exception e)
                {
                    e.ToString();

                }
            }
            public static void LogHelper(string MethodName, object RequestObj, object ResponseObj, OperationContext oOperationContext, Exception ex)
            {
                Log log = new Log();
                log.ActivityDate = DateTime.Now.ToString();
                log.ClientIP = CommonHelper.GetClientIP(oOperationContext);
                log.ExceptionMessage = string.Format("{0}\r\nStack Trace: {1}\r\n", ex.Message, ex.StackTrace);
                log.MethodCalled = MethodName;
                log.RequestParams = RequestObj == null ? string.Empty : (string)RequestObj;
                log.ResponseParams = ResponseObj == null ? string.Empty : GetProperties(ResponseObj);
                log.Type = LogType.ExceptionLog.ToString();
                Log(log);
            }

            public static void LogHelper(string MethodName, object ResponseObj, OperationContext oOperationContext, Exception ex)
            {
                Log log = new Log();
                log.ActivityDate = DateTime.Now.ToString();
                log.ClientIP = CommonHelper.GetClientIP(oOperationContext);
                log.ExceptionMessage = string.Format("{0}\r\nStack Trace: {1}\r\n", ex.Message, ex.StackTrace);
                log.MethodCalled = MethodName;
                log.ResponseParams = "";
                log.Type = LogType.ExceptionLog.ToString();
                Log(log);
            }

            public static void LogHelper(string MethodName, object obj, OperationContext oOperationContext)
            {
                Log log = new Log();
                log.ActivityDate = DateTime.Now.ToString();
                log.ClientIP = CommonHelper.GetClientIP(oOperationContext);
                log.MethodCalled = MethodName;
                log.RequestParams = obj == null ? string.Empty : GetProperties(obj);
                log.Type = LogType.ActivityLog.ToString();
                Log(log);
            }
            public static void LogHelper(string MethodName, string phonnumber, OperationContext oOperationContext)
            {
                Log log = new Log();
                log.ActivityDate = DateTime.Now.ToString();
                log.ClientIP = CommonHelper.GetClientIP(oOperationContext);
                log.MethodCalled = MethodName;
                log.RequestParams = phonnumber == null ? string.Empty : phonnumber;
                log.Type = LogType.ActivityLog.ToString();
                Log(log);
            }
            public static string GetProperties(object obj)
            {
                var values = obj;
                var Properties = values.GetType().GetProperties();
                StringBuilder builder = new StringBuilder();

                foreach (PropertyInfo info in Properties)
                {
                    builder.Append(info.Name + " : " + info.GetValue(values, null));
                    builder.Append(Environment.NewLine);
                }

                return builder.ToString();
            }
            public enum LogType
            {
                ExceptionLog,
                ActivityLog
            }

        }
    }
}
