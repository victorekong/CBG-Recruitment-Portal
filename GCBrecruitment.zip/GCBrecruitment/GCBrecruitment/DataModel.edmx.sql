
-- --------------------------------------------------
-- Entity Designer DDL Script for SQL Server 2005, 2008, 2012 and Azure
-- --------------------------------------------------
-- Date Created: 08/16/2018 15:44:21
-- Generated from EDMX file: c:\users\rh223er\documents\visual studio 2013\Projects\GCBrecruitment\GCBrecruitment\DataModel.edmx
-- --------------------------------------------------

SET QUOTED_IDENTIFIER OFF;
GO
USE [CBGhanaRecruitmentPortal];
GO
IF SCHEMA_ID(N'dbo') IS NULL EXECUTE(N'CREATE SCHEMA [dbo]');
GO

-- --------------------------------------------------
-- Dropping existing FOREIGN KEY constraints
-- --------------------------------------------------

IF OBJECT_ID(N'[dbo].[FK_StaffBioData_MemberBank]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[StaffBioData] DROP CONSTRAINT [FK_StaffBioData_MemberBank];
GO
IF OBJECT_ID(N'[dbo].[FK_StaffBioData_StaffAuthInfo]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[StaffBioData] DROP CONSTRAINT [FK_StaffBioData_StaffAuthInfo];
GO

-- --------------------------------------------------
-- Dropping existing tables
-- --------------------------------------------------

IF OBJECT_ID(N'[dbo].[ErrorLog]', 'U') IS NOT NULL
    DROP TABLE [dbo].[ErrorLog];
GO
IF OBJECT_ID(N'[dbo].[MemberBank]', 'U') IS NOT NULL
    DROP TABLE [dbo].[MemberBank];
GO
IF OBJECT_ID(N'[dbo].[StaffAuthInfo]', 'U') IS NOT NULL
    DROP TABLE [dbo].[StaffAuthInfo];
GO
IF OBJECT_ID(N'[dbo].[StaffBioData]', 'U') IS NOT NULL
    DROP TABLE [dbo].[StaffBioData];
GO
IF OBJECT_ID(N'[dbo].[Title]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Title];
GO

-- --------------------------------------------------
-- Creating all tables
-- --------------------------------------------------

-- Creating table 'ErrorLogs'
CREATE TABLE [dbo].[ErrorLogs] (
    [ID] bigint IDENTITY(1,1) NOT NULL,
    [ErrorMessage] varchar(5000)  NOT NULL,
    [ErrorStackTrace] varchar(max)  NOT NULL,
    [ErrorDate] datetime  NOT NULL,
    [ExceptionTypeName] varchar(500)  NULL,
    [ExceptionSource] varchar(5000)  NULL,
    [ExceptionTargetSite] varchar(5000)  NULL,
    [AdditionalDetails] varchar(500)  NULL
);
GO

-- Creating table 'MemberBanks'
CREATE TABLE [dbo].[MemberBanks] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Name] varchar(30)  NOT NULL
);
GO

-- Creating table 'StaffAuthInfoes'
CREATE TABLE [dbo].[StaffAuthInfoes] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [EmailAddress] varchar(50)  NOT NULL
);
GO

-- Creating table 'StaffBioDatas'
CREATE TABLE [dbo].[StaffBioDatas] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Surname] varchar(30)  NOT NULL,
    [FirstName] varchar(30)  NOT NULL,
    [MiddleName] varchar(30)  NOT NULL,
    [TitleId] int  NOT NULL,
    [MemberBankId] int  NOT NULL,
    [CurrentGrade] varchar(30)  NOT NULL,
    [JobTitle] varchar(50)  NOT NULL,
    [JobFunction] varchar(5000)  NOT NULL,
    [CumulativeYearOfExperience] int  NOT NULL,
    [EmploymentYearsInMemberBank] int  NOT NULL,
    [LastPromotionDate] datetime  NOT NULL,
    [HighestEduQualification] varchar(1000)  NOT NULL,
    [ProfessionalCertification] varchar(1000)  NOT NULL,
    [Gender] char(1)  NOT NULL,
    [DateOfBirth] datetime  NOT NULL,
    [CVFileName] varchar(100)  NOT NULL,
    [DateCreated] datetime  NOT NULL,
    [StaffAuthInfoId] int  NOT NULL,
    [Title] varchar(10)  NULL
);
GO

-- Creating table 'Titles'
CREATE TABLE [dbo].[Titles] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Name] varchar(30)  NOT NULL
);
GO

-- --------------------------------------------------
-- Creating all PRIMARY KEY constraints
-- --------------------------------------------------

-- Creating primary key on [ID] in table 'ErrorLogs'
ALTER TABLE [dbo].[ErrorLogs]
ADD CONSTRAINT [PK_ErrorLogs]
    PRIMARY KEY CLUSTERED ([ID] ASC);
GO

-- Creating primary key on [Id] in table 'MemberBanks'
ALTER TABLE [dbo].[MemberBanks]
ADD CONSTRAINT [PK_MemberBanks]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'StaffAuthInfoes'
ALTER TABLE [dbo].[StaffAuthInfoes]
ADD CONSTRAINT [PK_StaffAuthInfoes]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'StaffBioDatas'
ALTER TABLE [dbo].[StaffBioDatas]
ADD CONSTRAINT [PK_StaffBioDatas]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'Titles'
ALTER TABLE [dbo].[Titles]
ADD CONSTRAINT [PK_Titles]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- --------------------------------------------------
-- Creating all FOREIGN KEY constraints
-- --------------------------------------------------

-- Creating foreign key on [MemberBankId] in table 'StaffBioDatas'
ALTER TABLE [dbo].[StaffBioDatas]
ADD CONSTRAINT [FK_StaffBioData_MemberBank]
    FOREIGN KEY ([MemberBankId])
    REFERENCES [dbo].[MemberBanks]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_StaffBioData_MemberBank'
CREATE INDEX [IX_FK_StaffBioData_MemberBank]
ON [dbo].[StaffBioDatas]
    ([MemberBankId]);
GO

-- Creating foreign key on [StaffAuthInfoId] in table 'StaffBioDatas'
ALTER TABLE [dbo].[StaffBioDatas]
ADD CONSTRAINT [FK_StaffBioData_StaffAuthInfo]
    FOREIGN KEY ([StaffAuthInfoId])
    REFERENCES [dbo].[StaffAuthInfoes]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_StaffBioData_StaffAuthInfo'
CREATE INDEX [IX_FK_StaffBioData_StaffAuthInfo]
ON [dbo].[StaffBioDatas]
    ([StaffAuthInfoId]);
GO

-- --------------------------------------------------
-- Script has ended
-- --------------------------------------------------